﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

            // couleur choisie dans la zone modifiable posee sur l'heure : prefixe des images de la palette
            const couleurZone = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 82,
              y: 164,
              w: 316,
              h: 142,
              select_image: 'coul_on.png',
              un_select_image: 'coul_off.png',
              default_type: 100001,
              optional_types: [
                { type: 100001, preview: 'coul_lavande.png', title_sc: '薰衣草', title_tc: '薰衣草', title_en: 'Lavender' },
                { type: 100002, preview: 'coul_bleu.png', title_sc: '蓝色', title_tc: '藍色', title_en: 'Blue' },
                { type: 100003, preview: 'coul_lime.png', title_sc: '青柠', title_tc: '青檸', title_en: 'Lime' },
              ],
              count: 3,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'coul_tips.png',
              tips_x: 58,
              tips_y: 148,
              tips_width: 200,
              tips_margin: 10,
            });
            let couleurType = couleurZone.getProperty(hmUI.prop.CURRENT_TYPE);
            // si la zone ne repond pas (AOD), le dernier choix lu par l'ecran normal sert
            try {
              if (couleurType) hmFS.SysProSetInt('mark40_couleur', couleurType);
              else couleurType = hmFS.SysProGetInt('mark40_couleur');
            } catch (e) {}
            const prefixe = { 100001: '', 100002: 'bleu_', 100003: 'lime_' }[couleurType] || '';
            const T = (nom) => prefixe + nom;
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: T('fond.png'),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 40,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 121,
              image_array: [T('hyb_01.png'),T('hyb_02.png'),T('hyb_03.png'),T('hyb_04.png'),T('hyb_05.png'),T('hyb_06.png'),T('hyb_07.png'),T('hyb_08.png'),T('hyb_09.png'),T('hyb_10.png'),T('hyb_11.png'),T('hyb_12.png'),T('hyb_13.png'),T('hyb_14.png'),T('hyb_15.png'),T('hyb_16.png'),T('hyb_17.png'),T('hyb_18.png'),T('hyb_19.png'),T('hyb_20.png'),T('hyb_21.png'),T('hyb_22.png'),T('hyb_23.png'),T('hyb_24.png'),T('hyb_25.png'),T('hyb_26.png'),T('hyb_27.png'),T('hyb_28.png'),T('hyb_29.png'),T('hyb_30.png')],
              image_length: 30,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 407,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'b_pct.png',
              unit_tc: 'b_pct.png',
              unit_en: 'b_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 388,
              image_array: [T('bat_01.png'),T('bat_02.png'),T('bat_03.png'),T('bat_04.png'),T('bat_05.png'),T('bat_06.png'),T('bat_07.png'),T('bat_08.png'),T('bat_09.png'),T('bat_10.png'),T('bat_11.png'),T('bat_12.png'),T('bat_13.png'),T('bat_14.png'),T('bat_15.png'),T('bat_16.png'),T('bat_17.png'),T('bat_18.png'),T('bat_19.png'),T('bat_20.png'),T('bat_21.png'),T('bat_22.png'),T('bat_23.png'),T('bat_24.png'),T('bat_25.png'),T('bat_26.png'),T('bat_27.png'),T('bat_28.png'),T('bat_29.png'),T('bat_30.png')],
              image_length: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 100,
              week_en: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_tc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_sc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 100,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 338,
              image_array: [T('weather_1.png'),T('weather_2.png'),T('weather_3.png'),"weather_4.png",T('weather_5.png'),T('weather_6.png'),T('weather_7.png'),T('weather_8.png'),T('weather_9.png'),T('weather_10.png'),T('weather_11.png'),T('weather_12.png'),T('weather_13.png'),T('weather_14.png'),T('weather_15.png'),T('weather_16.png'),T('weather_17.png'),T('weather_18.png'),T('weather_19.png'),T('weather_20.png'),T('weather_21.png'),T('weather_22.png'),T('weather_23.png'),T('weather_24.png'),T('weather_25.png'),T('weather_26.png'),T('weather_27.png'),T('weather_28.png'),"weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 348,
              font_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'w_deg.png',
              unit_tc: 'w_deg.png',
              unit_en: 'w_deg.png',
              negative_image: 'w_moins.png',
              invalid_image: 'w_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 171,
              hour_array: [T('h_0.png'),T('h_1.png'),T('h_2.png'),T('h_3.png'),T('h_4.png'),T('h_5.png'),T('h_6.png'),T('h_7.png'),T('h_8.png'),T('h_9.png')],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 171,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 407,
              second_startY: 219,
              second_array: [T('s_0.png'),T('s_1.png'),T('s_2.png'),T('s_3.png'),T('s_4.png'),T('s_5.png'),T('s_6.png'),T('s_7.png'),T('s_8.png'),T('s_9.png')],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // arcs des pas et des secondes : une image par niveau ; les pas restent pleins au-dela de l'objectif
            if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
              const niveau = (racine, k) => T(racine + (k < 10 ? '0' : '') + k + '.png');
              const arcPas = hmUI.createWidget(hmUI.widget.IMG, {
                x: 71, y: 10, src: niveau('pas_', 0), show_level: hmUI.show_level.ONLY_NORMAL,
              });
              const arcSec = hmUI.createWidget(hmUI.widget.IMG, {
                x: 427, y: 121, src: niveau('sec_', 0), show_level: hmUI.show_level.ONLY_NORMAL,
              });
              let capteurPas = null;
              let horloge = null;
              try {
                capteurPas = hmSensor.createSensor(hmSensor.id.STEP);
                horloge = hmSensor.createSensor(hmSensor.id.TIME);
              } catch (e) {}
              const majPas = () => {
                const part = capteurPas && capteurPas.target ? Math.min(1, capteurPas.current / capteurPas.target) : 0;
                arcPas.setProperty(hmUI.prop.MORE, { x: 71, y: 10, src: niveau('pas_', Math.round(part * 30)) });
              };
              const majSec = () => {
                const s = horloge ? horloge.second : 0;
                arcSec.setProperty(hmUI.prop.MORE, { x: 427, y: 121, src: niveau('sec_', s) });
              };
              let minuterie = null;
              const reprendre = () => {
                majPas();
                majSec();
                if (minuterie === null) minuterie = timer.createTimer(0, 1000, majSec, {});
              };
              const arreter = () => {
                if (minuterie !== null) timer.stopTimer(minuterie);
                minuterie = null;
              };
              try {
                capteurPas.addEventListener(hmSensor.event.CHANGE, majPas);
              } catch (e) {}
              reprendre();
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: reprendre, pause_call: arreter });
            }

            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 409,
              src: T('aod_pile.png'),
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 407,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'b_pct.png',
              unit_tc: 'b_pct.png',
              unit_en: 'b_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 100,
              week_en: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_tc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_sc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 100,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 171,
              hour_array: [T('h_0.png'),T('h_1.png'),T('h_2.png'),T('h_3.png'),T('h_4.png'),T('h_5.png'),T('h_6.png'),T('h_7.png'),T('h_8.png'),T('h_9.png')],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 171,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 21,
              w: 166,
              h: 62,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 402,
              w: 140,
              h: 65,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 335,
              w: 173,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 166,
              w: 171,
              h: 136,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 164,
              w: 166,
              h: 140,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 173,
              y: 91,
              w: 136,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -7,
              y: 181,
              w: 84,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}