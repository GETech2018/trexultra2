﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // couleur choisie dans la zone modifiable posee sur l'heure : prefixe des images de la palette ;
            // zone creee apres le fond, sinon il recouvre son apercu en mode edition
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 0, y: 0, w: 480, h: 480, src: 'edit_fond.png', show_level: hmUI.show_level.ONLY_EDIT,
            });
            const couleurZone = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10041,
              x: 20,
              y: 84,
              w: 330,
              h: 166,
              select_image: 'coul_on.png',
              un_select_image: 'coul_off.png',
              default_type: 100101,
              optional_types: [
                { type: 100101, preview: 'coul_bleu.png', title_sc: '蓝色', title_tc: '藍色', title_en: 'Blue' },
                { type: 100102, preview: 'coul_lime.png', title_sc: '青柠', title_tc: '青檸', title_en: 'Lime' },
                { type: 100103, preview: 'coul_lavande.png', title_sc: '薰衣草', title_tc: '薰衣草', title_en: 'Lavender' },
                { type: 100104, preview: 'coul_gris.png', title_sc: '灰色', title_tc: '灰色', title_en: 'Grey' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'coul_tips.png',
              tips_x: 65,
              tips_y: 6,
              tips_width: 200,
              tips_margin: 10,
            });
            let couleurType = couleurZone.getProperty(hmUI.prop.CURRENT_TYPE);
            // si la zone ne repond pas (AOD), le dernier choix lu par l'ecran normal sert
            try {
              if (couleurType) hmFS.SysProSetInt('mark42_couleur', couleurType);
              else couleurType = hmFS.SysProGetInt('mark42_couleur');
            } catch (e) {}
            const prefixe = { 100101: '', 100102: 'lime_', 100103: 'lavande_', 100104: 'gris_' }[couleurType] || '';
            const T = (nom) => prefixe + nom;
            normal_background_bg_img.setProperty(hmUI.prop.MORE, { x: 0, y: 0, src: T('fond.png') });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 393,
              y: 173,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'b_pct.png',
              unit_tc: 'b_pct.png',
              unit_en: 'b_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 179,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 30,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 32,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_deg.png',
              unit_tc: 't_deg.png',
              unit_en: 't_deg.png',
              negative_image: 't_moins.png',
              invalid_image: 't_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 232,
              y: 211,
              week_en: [T('day_fr_01.png'),T('day_fr_02.png'),T('day_fr_03.png'),T('day_fr_04.png'),T('day_fr_05.png'),T('day_fr_06.png'),T('day_fr_07.png')],
              week_tc: [T('day_fr_01.png'),T('day_fr_02.png'),T('day_fr_03.png'),T('day_fr_04.png'),T('day_fr_05.png'),T('day_fr_06.png'),T('day_fr_07.png')],
              week_sc: [T('day_fr_01.png'),T('day_fr_02.png'),T('day_fr_03.png'),T('day_fr_04.png'),T('day_fr_05.png'),T('day_fr_06.png'),T('day_fr_07.png')],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 377,
              day_startY: 212,
              day_sc_array: [T('d_0.png'),T('d_1.png'),T('d_2.png'),T('d_3.png'),T('d_4.png'),T('d_5.png'),T('d_6.png'),T('d_7.png'),T('d_8.png'),T('d_9.png')],
              day_tc_array: [T('d_0.png'),T('d_1.png'),T('d_2.png'),T('d_3.png'),T('d_4.png'),T('d_5.png'),T('d_6.png'),T('d_7.png'),T('d_8.png'),T('d_9.png')],
              day_en_array: [T('d_0.png'),T('d_1.png'),T('d_2.png'),T('d_3.png'),T('d_4.png'),T('d_5.png'),T('d_6.png'),T('d_7.png'),T('d_8.png'),T('d_9.png')],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 83,
              hour_array: [T('h_0.png'),T('h_1.png'),T('h_2.png'),T('h_3.png'),T('h_4.png'),T('h_5.png'),T('h_6.png'),T('h_7.png'),T('h_8.png'),T('h_9.png')],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 217,
              minute_startY: 95,
              minute_array: [T('m_0.png'),T('m_1.png'),T('m_2.png'),T('m_3.png'),T('m_4.png'),T('m_5.png'),T('m_6.png'),T('m_7.png'),T('m_8.png'),T('m_9.png')],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 343,
              second_startY: 131,
              second_array: [T('s_0.png'),T('s_1.png'),T('s_2.png'),T('s_3.png'),T('s_4.png'),T('s_5.png'),T('s_6.png'),T('s_7.png'),T('s_8.png'),T('s_9.png')],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 123,
              src: 'aod_pile.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 123,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'b_pct.png',
              unit_tc: 'b_pct.png',
              unit_en: 'b_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 306,
              week_en: [T('aod_day_fr_01.png'),T('aod_day_fr_02.png'),T('aod_day_fr_03.png'),T('aod_day_fr_04.png'),T('aod_day_fr_05.png'),T('aod_day_fr_06.png'),T('aod_day_fr_07.png')],
              week_tc: [T('aod_day_fr_01.png'),T('aod_day_fr_02.png'),T('aod_day_fr_03.png'),T('aod_day_fr_04.png'),T('aod_day_fr_05.png'),T('aod_day_fr_06.png'),T('aod_day_fr_07.png')],
              week_sc: [T('aod_day_fr_01.png'),T('aod_day_fr_02.png'),T('aod_day_fr_03.png'),T('aod_day_fr_04.png'),T('aod_day_fr_05.png'),T('aod_day_fr_06.png'),T('aod_day_fr_07.png')],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 275,
              day_startY: 307,
              day_sc_array: [T('aod_d_0.png'),T('aod_d_1.png'),T('aod_d_2.png'),T('aod_d_3.png'),T('aod_d_4.png'),T('aod_d_5.png'),T('aod_d_6.png'),T('aod_d_7.png'),T('aod_d_8.png'),T('aod_d_9.png')],
              day_tc_array: [T('aod_d_0.png'),T('aod_d_1.png'),T('aod_d_2.png'),T('aod_d_3.png'),T('aod_d_4.png'),T('aod_d_5.png'),T('aod_d_6.png'),T('aod_d_7.png'),T('aod_d_8.png'),T('aod_d_9.png')],
              day_en_array: [T('aod_d_0.png'),T('aod_d_1.png'),T('aod_d_2.png'),T('aod_d_3.png'),T('aod_d_4.png'),T('aod_d_5.png'),T('aod_d_6.png'),T('aod_d_7.png'),T('aod_d_8.png'),T('aod_d_9.png')],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 111,
              hour_startY: 162,
              hour_array: [T('aod_h_0.png'),T('aod_h_1.png'),T('aod_h_2.png'),T('aod_h_3.png'),T('aod_h_4.png'),T('aod_h_5.png'),T('aod_h_6.png'),T('aod_h_7.png'),T('aod_h_8.png'),T('aod_h_9.png')],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 272,
              minute_startY: 204,
              minute_array: [T('aod_m_0.png'),T('aod_m_1.png'),T('aod_m_2.png'),T('aod_m_3.png'),T('aod_m_4.png'),T('aod_m_5.png'),T('aod_m_6.png'),T('aod_m_7.png'),T('aod_m_8.png'),T('aod_m_9.png')],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 57,
              y: 256,
              w: 136,
              h: 136,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: T('prev_step.png') },
                { type: hmUI.edit_type.CAL, preview: T('prev_calories.png') },
                { type: 100001, preview: T('prev_vo2max.png'), title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.HEART, preview: T('prev_heart.png') },
                { type: hmUI.edit_type.DISTANCE, preview: T('prev_distance.png') },
                { type: 100002, preview: T('prev_bio_charge.png'), title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: T('prev_spo2.png') },
                { type: hmUI.edit_type.PAI, preview: T('prev_pai.png') },
                { type: 100003, preview: T('prev_training_load.png'), title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100004, preview: T('prev_altitude.png'), title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100005, preview: T('prev_humidity.png'), title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100006, preview: T('prev_uvi.png'), title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -7,
              tips_y: 140,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 82, w: 85,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 109,
                  y: 283,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 91, w: 68,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 111,
                  y: 284,
                  src: 'ic_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 99, w: 51,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 110,
                  y: 286,
                  src: 'ic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 99, w: 51,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 109,
                  y: 282,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 91, w: 68,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 113,
                  y: 285,
                  src: 'ic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 89, w: 72,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 103,
                  y: 282,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 108, w: 34, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 109, y: 282, src: 'ic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 99, w: 51, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 109, y: 286, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 91, w: 68, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 108, y: 286, src: 'ic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 91, w: 68, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 108, y: 287, src: 'ic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 89, w: 72, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 113, y: 285, src: 'ic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 108, w: 34, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 111, y: 282, src: 'ic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 156,
              y: 293,
              w: 168,
              h: 168,
              select_image: 'zoneg_on.png',
              un_select_image: 'zoneg_off.png',
              default_type: hmUI.edit_type.CAL,
              optional_types: [
                { type: hmUI.edit_type.CAL, preview: T('prevg_calories.png') },
                { type: 100001, preview: T('prevg_vo2max.png'), title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.HEART, preview: T('prevg_heart.png') },
                { type: hmUI.edit_type.DISTANCE, preview: T('prevg_distance.png') },
                { type: 100002, preview: T('prevg_bio_charge.png'), title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: T('prevg_spo2.png') },
                { type: hmUI.edit_type.PAI, preview: T('prevg_pai.png') },
                { type: 100003, preview: T('prevg_training_load.png'), title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100004, preview: T('prevg_altitude.png'), title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100005, preview: T('prevg_humidity.png'), title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100006, preview: T('prevg_uvi.png'), title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: hmUI.edit_type.STEP, preview: T('prevg_step.png') },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 9,
              tips_y: 118,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 186, w: 109,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 333,
                  src: 'icg_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 196, w: 87,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 224,
                  y: 334,
                  src: 'icg_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 208, w: 65,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  invalid_image: 'g_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 336,
                  src: 'icg_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 208, w: 65,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 332,
                  src: 'icg_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 196, w: 87,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  dot_image: 'g_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 226,
                  y: 335,
                  src: 'icg_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 194, w: 93,
                  y: 372,
                  font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'g_pct.png',
                  unit_tc: 'g_pct.png',
                  unit_en: 'g_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 216,
                  y: 332,
                  src: 'icg_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 218, w: 43, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 221, y: 332, src: 'icg_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 208, w: 65, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 222, y: 336, src: 'icg_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 196, w: 87, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 220, y: 336, src: 'icg_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 196, w: 87, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, negative_image: 'g_moins.png', invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 220, y: 337, src: 'icg_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 194, w: 93, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, unit_sc: 'g_pct.png', unit_tc: 'g_pct.png', unit_en: 'g_pct.png', invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 226, y: 335, src: 'icg_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 218, w: 43, y: 372, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: 1, invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 224, y: 332, src: 'icg_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 287,
              y: 256,
              w: 136,
              h: 136,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100001,
              optional_types: [
                { type: 100001, preview: T('prev_vo2max.png'), title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.HEART, preview: T('prev_heart.png') },
                { type: hmUI.edit_type.DISTANCE, preview: T('prev_distance.png') },
                { type: 100002, preview: T('prev_bio_charge.png'), title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: T('prev_spo2.png') },
                { type: hmUI.edit_type.PAI, preview: T('prev_pai.png') },
                { type: 100003, preview: T('prev_training_load.png'), title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100004, preview: T('prev_altitude.png'), title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100005, preview: T('prev_humidity.png'), title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100006, preview: T('prev_uvi.png'), title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: hmUI.edit_type.STEP, preview: T('prev_step.png') },
                { type: hmUI.edit_type.CAL, preview: T('prev_calories.png') },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -7,
              tips_y: 140,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313, w: 85,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 339,
                  y: 283,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321, w: 68,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 341,
                  y: 284,
                  src: 'ic_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 330, w: 51,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 340,
                  y: 286,
                  src: 'ic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 330, w: 51,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 339,
                  y: 282,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321, w: 68,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 343,
                  y: 285,
                  src: 'ic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 319, w: 72,
                  y: 316,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 333,
                  y: 282,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 338, w: 34, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 339, y: 282, src: 'ic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 330, w: 51, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 339, y: 286, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 321, w: 68, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 338, y: 286, src: 'ic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 321, w: 68, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 338, y: 287, src: 'ic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 319, w: 72, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 343, y: 285, src: 'ic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 338, w: 34, y: 316, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 341, y: 282, src: 'ic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 344,
              y: 160,
              w: 115,
              h: 47,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 21,
              w: 131,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 217,
              y: 85,
              w: 125,
              h: 117,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -1,
              y: 83,
              w: 216,
              h: 171,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 205,
              w: 217,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}