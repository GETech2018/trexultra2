﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 59,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 86,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 366,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 430,
              font_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 's_pct.png',
              unit_tc: 's_pct.png',
              unit_en: 's_pct.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 14,
              hour_startY: 118,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 196,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: 17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'liseres.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_lignes.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 59,
              week_en: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              week_tc: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              week_sc: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 86,
              day_sc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_tc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_en_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 346,
              month_startY: 74,
              month_sc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_tc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_en_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 14,
              hour_startY: 118,
              hour_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              hour_zero: 1,
              hour_space: 17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 196,
              minute_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              minute_zero: 1,
              minute_space: 17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 350,
              w: 104,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 417,
              w: 122,
              h: 73,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 192,
              w: 261,
              h: 217,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 162,
              y: 27,
              w: 186,
              h: 106,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 123,
              w: 219,
              h: 224,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}