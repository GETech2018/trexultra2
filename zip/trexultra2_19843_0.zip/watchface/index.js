﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// soleil sur l'arc du haut (lever -> coucher) et point sur l'arc des temperatures (min -> max du jour)
// angles trigonometriques et rayons de tools/layout.py

const SOL_R = 221.7
const SOL_A0 = 131.4
const SOL_A1 = 49.6
const SOL_TAILLE = 36
const TEMP_R = 221.7
const TEMP_A0 = 241.0
const TEMP_A1 = 308.5
const POINT_TAILLE = 18

let solImg = null
let pointImg = null
let solTemps = null
let solMeteo = null

function surArc(r, a, taille) {
  const t = (a * Math.PI) / 180
  return { x: Math.round(240 + r * Math.cos(t) - taille / 2), y: Math.round(240 - r * Math.sin(t) - taille / 2) }
}

function solCreer() {
  solImg = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: "soleil.png", show_level: hmUI.show_level.ONLY_NORMAL })
  pointImg = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: "point.png", show_level: hmUI.show_level.ONLY_NORMAL })
  solTemps = hmSensor.createSensor(hmSensor.id.TIME)
  solMeteo = hmSensor.createSensor(hmSensor.id.WEATHER)
  solTemps.addEventListener(solTemps.event.MINUTEEND, function () {
    solMaj()
    tempMaj()
  })
}

// avant le lever : bout gauche, apres le coucher : bout droit ; cache sans meteo synchronisee
function solMaj() {
  const meteo = solMeteo.getForecastWeather()
  const marees = meteo && meteo.tideData
  if (!marees || !marees.count) {
    solImg.setProperty(hmUI.prop.VISIBLE, false)
    return
  }
  const j = marees.data[0]
  const lever = j.sunrise.hour * 60 + j.sunrise.minute
  const coucher = j.sunset.hour * 60 + j.sunset.minute
  const now = solTemps.hour * 60 + solTemps.minute
  const p = coucher > lever ? Math.max(0, Math.min(1, (now - lever) / (coucher - lever))) : 0.5
  const xy = surArc(SOL_R, SOL_A0 + p * (SOL_A1 - SOL_A0), SOL_TAILLE)
  solImg.setProperty(hmUI.prop.MORE, { x: xy.x, y: xy.y, src: "soleil.png" })
  solImg.setProperty(hmUI.prop.VISIBLE, true)
}

function tempMaj() {
  const meteo = solMeteo.getForecastWeather()
  const prev = meteo && meteo.forecastData
  const actuelle = solMeteo.current
  if (!prev || !prev.count || actuelle == undefined) {
    pointImg.setProperty(hmUI.prop.VISIBLE, false)
    return
  }
  const j = prev.data[0]
  const p = j.high > j.low ? Math.max(0, Math.min(1, (actuelle - j.low) / (j.high - j.low))) : 0.5
  const xy = surArc(TEMP_R, TEMP_A0 + p * (TEMP_A1 - TEMP_A0), POINT_TAILLE)
  pointImg.setProperty(hmUI.prop.MORE, { x: xy.x, y: xy.y, src: "point.png" })
  pointImg.setProperty(hmUI.prop.VISIBLE, true)
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 68,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 65,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 134,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png","bat_11.png","bat_12.png","bat_13.png","bat_14.png","bat_15.png","bat_16.png","bat_17.png","bat_18.png","bat_19.png","bat_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 126,
              image_array: ["pas_01.png","pas_02.png","pas_03.png","pas_04.png","pas_05.png","pas_06.png","pas_07.png","pas_08.png","pas_09.png","pas_10.png","pas_11.png","pas_12.png","pas_13.png","pas_14.png","pas_15.png","pas_16.png","pas_17.png","pas_18.png","pas_19.png","pas_20.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 95,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 126,
              image_array: ["cal_01.png","cal_02.png","cal_03.png","cal_04.png","cal_05.png","cal_06.png","cal_07.png","cal_08.png","cal_09.png","cal_10.png","cal_11.png","cal_12.png","cal_13.png","cal_14.png","cal_15.png","cal_16.png","cal_17.png","cal_18.png","cal_19.png","cal_20.png"],
              image_length: 20,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 95,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 377,
              y: 126,
              image_array: ["fc_01.png","fc_02.png","fc_03.png","fc_04.png","fc_05.png","fc_06.png","fc_07.png","fc_08.png","fc_09.png","fc_10.png","fc_11.png","fc_12.png","fc_13.png","fc_14.png","fc_15.png","fc_16.png","fc_17.png","fc_18.png","fc_19.png","fc_20.png"],
              image_length: 20,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 95,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'v_tiret.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 334,
              src: 'pastilles.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 94,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 60,
              minute_startY: 244,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 362,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 112,
              month_startY: 362,
              month_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              month_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              month_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 362,
              week_en: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_tc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              week_sc: ["day_fr_01.png","day_fr_02.png","day_fr_03.png","day_fr_04.png","day_fr_05.png","day_fr_06.png","day_fr_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 46,
              font_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              padding: true,
              h_space: -1,
              dot_image: 's_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 46,
              font_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              padding: true,
              h_space: -1,
              dot_image: 's_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 407,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 414,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_deg.png',
              unit_tc: 't_deg.png',
              unit_en: 't_deg.png',
              negative_image: 't_minus.png',
              invalid_image: 't_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
solCreer()
solMaj()
tempMaj()

            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 216,
              src: 'aod_statique.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 94,
              hour_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 159,
              minute_startY: 244,
              minute_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 166,
              day_startY: 362,
              day_sc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_tc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_en_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 362,
              month_sc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              month_tc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              month_en_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 266,
              y: 362,
              week_en: ["aod_day_fr_01.png","aod_day_fr_02.png","aod_day_fr_03.png","aod_day_fr_04.png","aod_day_fr_05.png","aod_day_fr_06.png","aod_day_fr_07.png"],
              week_tc: ["aod_day_fr_01.png","aod_day_fr_02.png","aod_day_fr_03.png","aod_day_fr_04.png","aod_day_fr_05.png","aod_day_fr_06.png","aod_day_fr_07.png"],
              week_sc: ["aod_day_fr_01.png","aod_day_fr_02.png","aod_day_fr_03.png","aod_day_fr_04.png","aod_day_fr_05.png","aod_day_fr_06.png","aod_day_fr_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 97,
              w: 63,
              h: 291,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 97,
              w: 60,
              h: 291,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 97,
              w: 60,
              h: 291,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 140,
              w: 48,
              h: 200,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 30,
              w: 200,
              h: 44,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 404,
              w: 180,
              h: 46,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 233,
              w: 165,
              h: 118,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 356,
              w: 190,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 95,
              w: 152,
              h: 132,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

solMaj()
tempMaj()

                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}