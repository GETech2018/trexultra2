﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// arc des temperatures du jour : une image temp_ par niveau, de la min (bout gauche) a la max (bout droit)

const ARC_N = 24

let arcImage = null
let arcMeteo = null
let arcTemps = null

function arcCreer() {
  arcImage = hmUI.createWidget(hmUI.widget.IMG, { x: 92, y: 384, src: "temp_00.png", show_level: hmUI.show_level.ONLY_NORMAL })
  arcMeteo = hmSensor.createSensor(hmSensor.id.WEATHER)
  arcTemps = hmSensor.createSensor(hmSensor.id.TIME)
  arcTemps.addEventListener(arcTemps.event.MINUTEEND, arcMaj)
}

function arcMaj() {
  const meteo = arcMeteo.getForecastWeather()
  const prev = meteo && meteo.forecastData
  const actuelle = arcMeteo.current
  if (!prev || !prev.count || actuelle == undefined) {
    arcImage.setProperty(hmUI.prop.VISIBLE, false)
    return
  }
  const j = prev.data[0]
  const p = j.high > j.low ? Math.max(0, Math.min(1, (actuelle - j.low) / (j.high - j.low))) : 0.5
  const n = Math.round(p * ARC_N)
  arcImage.setProperty(hmUI.prop.MORE, { x: 92, y: 384, src: "temp_" + (n < 10 ? "0" : "") + n + ".png" })
  arcImage.setProperty(hmUI.prop.VISIBLE, true)
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 19;
        let normal_temperature_low_TextRotate_unit = null;
        let normal_temperature_low_TextRotate_unit_width = 11;
        let normal_temperature_low_TextRotate_dot_width = 11;
        let normal_temperature_low_TextRotate_error_img_width = 20;
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 19;
        let normal_temperature_high_TextRotate_unit = null;
        let normal_temperature_high_TextRotate_unit_width = 11;
        let normal_temperature_high_TextRotate_dot_width = 11;
        let normal_temperature_high_TextRotate_error_img_width = 20;
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 186;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_minute = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 164;
        let normal_digital_clock_img_time_hour = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 388,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 154,
              // y: 389,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: 22,
              // unit_en: 't_deg.png',
              // imperial_unit_en: 't_deg.png',
              // invalid_image: 't_null.png',
              // dot_image: 't_moins.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 154,
                center_y: 389,
                pos_x: 154,
                pos_y: 389,
                angle: 22,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 154,
              center_y: 389,
              pos_x: 154,
              pos_y: 389,
              angle: 22,
              src: 't_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 't_deg.png');
            };
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 326,
              // y: 389,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: -22,
              // unit_en: 't_deg.png',
              // imperial_unit_en: 't_deg.png',
              // invalid_image: 't_null.png',
              // dot_image: 't_moins.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 326,
                center_y: 389,
                pos_x: 326,
                pos_y: 389,
                angle: -22,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 326,
              center_y: 389,
              pos_x: 326,
              pos_y: 389,
              angle: -22,
              src: 't_deg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 't_deg.png');
            };
            //#endregion

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 32,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 't_pct.png',
              unit_tc: 't_pct.png',
              unit_en: 't_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 36,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 74,
              y: 86,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 86,
              day_sc_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_tc_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_en_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 157,
              // y: 230,
              // font_array: ["me_0.png","me_1.png","me_2.png","me_3.png","me_4.png","me_5.png","me_6.png","me_7.png","me_8.png","me_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -83,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'me_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'me_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'me_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'me_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'me_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'me_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'me_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'me_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'me_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'me_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 157,
                center_y: 230,
                pos_x: 157,
                pos_y: 230,
                angle: 0,
                src: 'me_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 157,
              minute_startY: 230,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: -83,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 28,
              // y: 117,
              // font_array: ["he_0.png","he_1.png","he_2.png","he_3.png","he_4.png","he_5.png","he_6.png","he_7.png","he_8.png","he_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -68,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'he_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'he_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'he_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'he_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'he_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'he_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'he_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'he_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'he_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'he_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 28,
                center_y: 117,
                pos_x: 28,
                pos_y: 117,
                angle: 0,
                src: 'he_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 28,
              hour_startY: 117,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -68,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
arcCreer()
arcMaj()

            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 32,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 't_pct.png',
              unit_tc: 't_pct.png',
              unit_en: 't_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 36,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 74,
              y: 86,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 86,
              day_sc_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_tc_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_en_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 157,
              minute_startY: 230,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: -83,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 28,
              hour_startY: 117,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -68,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 302,
              y: 76,
              w: 120,
              h: 120,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: hmUI.edit_type.CAL, preview: 'prev_cal.png' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: hmUI.edit_type.STRESS, preview: 'prev_stress.png' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: hmUI.edit_type.STAND, preview: 'prev_stand.png' },
{ type: 100001, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
{ type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
{ type: 100003, preview: 'prev_weather_current.png', title_sc: '当前温度', title_tc: '目前溫度', title_en: 'Temperature' },
{ type: 100004, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -16,
              tips_y: 122,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 346,
                  y: 99,
                  src: 'ic_pas.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 345,
                  y: 99,
                  src: 'ic_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  invalid_image: 't_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 342,
                  y: 100,
                  src: 'ic_coeur.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 342,
                  y: 99,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 't_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 346,
                  y: 99,
                  src: 'ic_course.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 346,
                  y: 99,
                  src: 'ic_debout.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 320,
                  y: 99,
                  src: 'ic_stress.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 312, w: 100,
                  y: 143,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 't_pct.png',
                  unit_tc: 't_pct.png',
                  unit_en: 't_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 334,
                  y: 99,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.IMG, { x: 338, y: 99, src: 'ic_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 326, y: 143, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.IMG, { x: 340, y: 99, src: 'ic_vo2.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 326, y: 143, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 312, y: 117, w: 99, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: -3, unit_sc: 'g_deg.png', unit_tc: 'g_deg.png', unit_en: 'g_deg.png', imperial_unit_sc: 'g_deg.png', imperial_unit_tc: 'g_deg.png', imperial_unit_en: 'g_deg.png', negative_image: 'g_moins.png', invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.IMG, { x: 340, y: 99, src: 'ic_hybrid.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 326, y: 143, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 36,
              y: 259,
              w: 120,
              h: 120,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: hmUI.edit_type.CAL, preview: 'prev_cal.png' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: hmUI.edit_type.STRESS, preview: 'prev_stress.png' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: hmUI.edit_type.STAND, preview: 'prev_stand.png' },
{ type: 100001, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
{ type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
{ type: 100003, preview: 'prev_weather_current.png', title_sc: '当前温度', title_tc: '目前溫度', title_en: 'Temperature' },
{ type: 100004, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
              ],
              count: 12,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -15,
              tips_y: 122,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 81,
                  y: 282,
                  src: 'ic_pas.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 80,
                  y: 282,
                  src: 'ic_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  invalid_image: 't_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 77,
                  y: 283,
                  src: 'ic_coeur.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 76,
                  y: 282,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 't_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 81,
                  y: 282,
                  src: 'ic_course.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_2_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 80,
                  y: 282,
                  src: 'ic_debout.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 55,
                  y: 282,
                  src: 'ic_stress.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 46, w: 100,
                  y: 327,
                  font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 't_pct.png',
                  unit_tc: 't_pct.png',
                  unit_en: 't_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 68,
                  y: 282,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.IMG, { x: 73, y: 282, src: 'ic_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 61, y: 327, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.IMG, { x: 74, y: 282, src: 'ic_vo2.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 61, y: 327, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 47, y: 300, w: 99, font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"], padding: false, h_space: -3, unit_sc: 'g_deg.png', unit_tc: 'g_deg.png', unit_en: 'g_deg.png', imperial_unit_sc: 'g_deg.png', imperial_unit_tc: 'g_deg.png', imperial_unit_en: 'g_deg.png', negative_image: 'g_moins.png', invalid_image: 'g_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.IMG, { x: 75, y: 282, src: 'ic_hybrid.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 61, y: 327, w: 70, font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"], padding: false, h_space: -2, invalid_image: 't_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 21,
              w: 130,
              h: 52,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 385,
              w: 220,
              h: 63,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 247,
              w: 183,
              h: 118,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 78,
              w: 144,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 132,
              w: 178,
              h: 101,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 154 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 154 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 't_moins.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 154 + img_offset);
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 154);
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 't_null.png');
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_img_width * normal_temperature_high_rotate_string.length;
                  normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_posOffset + -2 * (normal_temperature_high_rotate_string.length - 1);
                  normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_posOffset + normal_temperature_high_TextRotate_unit_width + -2;
                  img_offset -= normal_temperature_high_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 326 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 326 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 't_moins.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 326 + img_offset);
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 326 - normal_temperature_high_TextRotate_error_img_width / 2);
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 't_null.png');
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 157 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -83;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 28 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -68;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

arcMaj()

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}