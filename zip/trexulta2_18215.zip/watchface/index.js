﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();

const packageInfo = hmApp.packageInfo();
WF_ID = packageInfo.appId;

let kf = D_W / 466;

let normal_weather_image_progress_img_level_ic = ''

function loadSettings() {
 /*    color_ic = hmFS.SysProGetInt(`${WF_ID}_color_ic`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_color_ic`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_color_ic`);
     tip_grafik = hmFS.SysProGetInt(`${WF_ID}_tip_grafik`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tip_grafik`);

     if (hmFS.SysProGetInt(`${WF_ID}_crown`) === undefined) {
         crown = 0;
         hmFS.SysProSetInt(`${WF_ID}_crown`, crown);
     } else {
         crown = hmFS.SysProGetInt(`${WF_ID}_crown`);
     }*/

 tap_str = hmFS.SysProGetInt(`${WF_ID}_tap_str`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tap_str`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tap_str`);
 block = hmFS.SysProGetInt(`${WF_ID}_block`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_block`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_block`);
 //    longpress_tap_left = hmFS.SysProGetInt(`${WF_ID}_longpress_tap_left`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_longpress_tap_left`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_longpress_tap_left`);


 // ЗАГРУЖАЕМ ВСЕ КНОПКИ (включая 7-ю) - УБЕРИТЕ -1
 //    for (let i = 0; i < CONF_MAIN.length; i++) {
 //        const defaultValue = CONF_MAIN[i].id;
 //        CONF_MAIN[i].id = hmFS.SysProGetInt(`${WF_ID}_color_` + i) === undefined
 //            ? (hmFS.SysProSetInt(`${WF_ID}_color_` + i, defaultValue), defaultValue)
 //            : hmFS.SysProGetInt(`${WF_ID}_color_` + i);
 //    }

}


let tap_str = 0
function clik_tap_str() {
 tap_str = (tap_str + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_tap_str`, tap_str);
 normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
 vibro();
}


const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

function vibro(scene = 25) {
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();
}

function stopVibro() {
 vibrate.stop();
 timer.stopTimer(stopVibro_Timer);
}

function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}

function updatePressere() {
 let pressure_array = read_pressure();
 let value = getPressureValue(pressure_array);
 value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


 let pressere_changes_str = "=";
 //let color_pressere = 0x00ff00;
 let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

 let pressere_changes = changesPressure(pressure_array);
 if (pressere_changes < 0) {
  pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
 }
 if (pressere_changes > 0) {
  pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
 }
 //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

 let value_str = value == 0 ? "--" : value + pressere_changes_str;
 normal_widget_text_3.setProperty(hmUI.prop.TEXT, value_str);
 //text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);

 // Line_arr[2][1] = value_str;
}

// Датчик пульса
let heart = hmSensor.createSensor(hmSensor.id.HEART);

function updateHeartMinMax() {
 let todayData = heart.today;
 if (!todayData || todayData.length === 0) return;

 let periodData = todayData.slice(-60); // последние 60 минут
 let valid = periodData.filter(v => v && v > 0);
 if (valid.length === 0) return;

 let minVal = Math.min(...valid);
 let maxVal = Math.max(...valid);

 normal_widget_text_1.setProperty(hmUI.prop.TEXT, minVal.toString());
 normal_widget_text_2.setProperty(hmUI.prop.TEXT, maxVal.toString());
}

let normal_block_FILL_RECT = ""
let btn_block = ""
let block = 0

function clik_block() {
 block = (block + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_block`, block);
 normal_widget_text_8.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКРЫТО' : 'БЛОК');
 normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);
 btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
 vibro();
}

		// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_day_month_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas22.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 286,
              h: 49,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFB9C0B5,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 597,
              h: 102,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Bold.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 232,
              h: 34,
              text_size: 16,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald_AL-Bold.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 226,
              h: 34,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald_AL-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            loadSettings()
            hmUI.createWidget(hmUI.widget.TEXT, {
             x: D_W-2,
             y: D_W-2,
             w: 295 * kf,
             h: 30 * kf,
             text_size: 16 * kf,
             char_space: 1,
             line_space: 0,
             font: 'fonts/Oswald-Bold.ttf',
             color: 0xFFFFFFFF,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             text_style: hmUI.text_style.ELLIPSIS,
             text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
             show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TEXT, {
             x: D_W-2,
             y: D_W-2,
             w: 295 * kf,
             h: 30 * kf,
             text_size: 24 * kf,
             char_space: 1,
             line_space: 0,
             font: 'fonts/Bebas22.ttf',
             color: 0xFFFFFFFF,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             text_style: hmUI.text_style.ELLIPSIS,
             text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/↓↑",
             show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 336,
              y: 171,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 278,
              image_array: ["wt_0.png","wt_1.png","wt_2.png","wt_3.png","wt_4.png","wt_5.png","wt_6.png","wt_7.png","wt_8.png","wt_9.png","wt_10.png","wt_11.png","wt_12.png","wt_13.png","wt_14.png","wt_15.png","wt_16.png","wt_17.png","wt_18.png","wt_19.png","wt_20.png","wt_21.png","wt_22.png","wt_23.png","wt_24.png","wt_25.png","wt_26.png","wt_27.png","wt_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 202,
              src: 'bg_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 309,
              y: 325,
              w: 155,
              h: 31,
              text_size: 23,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFB9C0B5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 281,
              y: 124,
              w: 155,
              h: 31,
              text_size: 23,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFB9C0B5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 89,
              w: 155,
              h: 37,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 298,
              y: 202,
              w: 155,
              h: 72,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 124,
              // center_y: 240,
              // start_angle: -180,
              // end_angle: 90,
              // radius: 55,
              // line_width: 4,
              // line_cap: Flat,
              // color: 0xFF96D9E7,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 124,
              center_y: 240,
              start_angle: -180,
              end_angle: 90,
              radius: 53,
              line_width: 4,
              corner_flag: 3,
              color: 0xFF96D9E7,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 252,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_bat.png',
              center_x: 124,
              center_y: 240,
              x: 12,
              y: 41,
              start_angle: -180,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 179,
              y: 369,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 179,
              y: 333,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 337,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 271,
              y: 171,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 339,
              y: 352,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 121,
              w: 155,
              h: 37,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFB9C0B5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 191,
              y: 121,
              w: 155,
              h: 37,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFB9C0B5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '999',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 47,
              y: 135,
              w: 155,
              h: 31,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Bebas22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '129',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 5,
              y: 5,
              w: 470,
              h: 470,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: -60,
              end_angle: -30,
              mode: 0,
              // radius: 235,
              align_h: hmUI.align.CENTER_H,
              text: 'НАЙТИ ТЕЛ.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 5,
              y: 5,
              w: 470,
              h: 470,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: -90,
              end_angle: -60,
              mode: 0,
              // radius: 235,
              align_h: hmUI.align.CENTER_H,
              text: 'ТАЙМЕР',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: 240,
              end_angle: 270,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              text: 'ПОГОДА',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: 210,
              end_angle: 240,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              text: 'КАЛЕНДАРЬ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 210,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              text: 'ОТКРЫТО',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 5,
              y: 5,
              w: 470,
              h: 470,
              text_size: 16,
              char_space: 1,
              font: 'fonts/Oswald-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: -30,
              end_angle: 0,
              mode: 0,
              // radius: 235,
              align_h: hmUI.align.CENTER_H,
              text: 'БУДИЛЬНИК',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 381,
              y: 131,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 128,
              y: 2,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 5,
              y: 5,
              w: 470,
              h: 470,
              text_size: 16,
              char_space: 0,
              font: 'fonts/Oswald_AL-Bold.ttf',
              color: 0xFFC0C0C0,
              // use_text_circle: true,
              start_angle: -30,
              end_angle: -3,
              mode: 0,
              // radius: 235,
              align_h: hmUI.align.RIGHT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
			normal_weather_image_progress_img_level_ic = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
			 x: 339*kf,
			 y: 79*kf,
			 image_array: ["wi_0.png", "wi_1.png", "wi_2.png", "wi_3.png", "wi_4.png", "wi_5.png", "wi_6.png", "wi_7.png", "wi_8.png", "wi_9.png", "wi_10.png", "wi_11.png", "wi_12.png", "wi_13.png", "wi_14.png", "wi_15.png", "wi_16.png", "wi_17.png", "wi_18.png", "wi_19.png", "wi_20.png", "wi_21.png", "wi_22.png", "wi_23.png", "wi_24.png", "wi_25.png", "wi_26.png", "wi_27.png", "wi_28.png"],
			 image_length: 29,
			 type: hmUI.data_type.WEATHER_CURRENT,
			 show_level: hmUI.show_level.ONLY_NORMAL,
			});
            // end user_script.js

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 29,
              hour_posY: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 35,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 29,
              hour_posY: 128,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 59,
              y: 56,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 4,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 148,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 251,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                //hmApp.startApp({url: 'WeatherScreen', native: true });
launchAppOrAppId('WeatherScreen', 1051195);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 343,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                //hmApp.startApp({url: 'ScheduleCalScreen', native: true });
launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 390,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_block();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 188,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_tap_str();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

    normal_block_FILL_RECT = hmUI.createWidget(hmUI.widget.FILL_RECT, {
     x: 0,
     y: 0,
     w: D_W,
     h: D_W,
     color: 0x000000,
     alpha: 0,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);

    btn_block = hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 141 * kf,
     y: 379 * kf,
     text: '',
     w: 80 * kf,
     h: 80 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
     //             click_func: () => {
     //                 vibro();
     //                 clik_tap_left();
     //             },
     longpress_func: () => {
      // vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);

    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, tap_str == 0);
    normal_widget_text_8.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКРЫТО' : 'БЛОК');

    heart.addEventListener(hmSensor.event.CHANGE, function () {
     updateHeartMinMax();
    });
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 124,
                      center_y: 240,
                      start_angle: -180,
                      end_angle: 90,
                      radius: 53,
                      line_width: 4,
                      corner_flag: 3,
                      color: 0xFF96D9E7,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

loadSettings();
updatePressere();
updateHeartMinMax();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}