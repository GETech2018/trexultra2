﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// heure en toutes lettres, date composee mot a mot, mot meteo colle a la temperature de l'editeur
// TABLE (encre des images en px, positions, langue du dossier) est reecrite par tools/build_assets.py

const TABLE = {"filet_x": 101, "filet_y": 297, "mt_one": 140.1, "mt_two": 154.4, "mt_three": 220.8, "mt_four": 179.9, "mt_five": 139.0, "mt_six": 104.5, "mt_seven": 218.4, "mt_eight": 195.2, "mt_nine": 150.8, "mt_ten": 129.2, "mt_eleven": 254.5, "mt_twelve": 267.2, "mt_oclock": 298.1, "mt_thirteen": 277.0, "mt_fourteen": 301.5, "mt_fifteen": 263.5, "mt_sixteen": 274.1, "mt_seventeen": 316.4, "mt_eighteen": 279.6, "mt_nineteen": 276.6, "mt_twenty": 280.0, "mt_thirty": 236.0, "mt_forty": 218.4, "mt_fifty": 177.2, "mt_oh": 95.4, "mt_minuit": 220.1, "mt_une": 133.8, "mt_deux": 179.0, "mt_trois": 198.0, "mt_quatre": 265.4, "mt_cinq": 160.6, "mt_sept": 170.8, "mt_huit": 148.9, "mt_neuf": 175.0, "mt_dix": 105.1, "mt_onze": 179.5, "mt_midi": 130.1, "mt_treize": 229.5, "mt_quatorze": 304.6, "mt_quinze": 242.8, "mt_seize": 185.1, "mt_dixsept": 292.6, "mt_dixhuit": 273.2, "mt_dixneuf": 299.4, "mt_vingt": 198.6, "mt_vingtetune": 325.9, "mt_vingtdeux": 325.9, "mt_vingttrois": 326.1, "mt_douze": 224.0, "mt_trente": 260.1, "mt_quarante": 365.0, "mt_cinquante": 327.5, "mt_etune": 232.6, "mt_am": 32.8, "mt_pm": 30.4, "marge": 102.7, "bases": [166.9, 226.1, 286.9], "mot_base": 65, "pm_ecart": 7.7, "mt_vheures_h": 50.5, "mt_vheure_h": 42.1, "marqueur_ecart": 5, "dj_en_1": 93.4, "dj_en_1_g": 1.2, "dj_en_2": 100.7, "dj_en_2_g": 0.1, "dj_en_3": 137.1, "dj_en_3_g": 0.0, "dj_en_4": 117.1, "dj_en_4_g": 0.1, "dj_en_5": 76.8, "dj_en_5_g": 1.4, "dj_en_6": 114.5, "dj_en_6_g": 0.5, "dj_en_7": 89.1, "dj_en_7_g": 0.5, "dm_en_1": 99.1, "dm_en_1_g": 0.2, "dm_en_2": 113.6, "dm_en_2_g": 1.4, "dm_en_3": 78.0, "dm_en_3_g": 1.2, "dm_en_4": 62.6, "dm_en_4_g": 0.4, "dm_en_5": 44.5, "dm_en_5_g": 1.2, "dm_en_6": 56.3, "dm_en_6_g": 0.2, "dm_en_7": 51.1, "dm_en_7_g": 0.2, "dm_en_8": 88.1, "dm_en_8_g": 0.4, "dm_en_9": 130.2, "dm_en_9_g": 0.5, "dm_en_10": 104.3, "dm_en_10_g": 0.6, "dm_en_11": 119.9, "dm_en_11_g": 1.2, "dm_en_12": 119.0, "dm_en_12_g": 1.5, "dj_fr_1": 62.0, "dj_fr_1_g": 1.5, "dj_fr_2": 68.0, "dj_fr_2_g": 1.2, "dj_fr_3": 110.4, "dj_fr_3_g": 1.2, "dj_fr_4": 61.3, "dj_fr_4_g": 0.2, "dj_fr_5": 107.7, "dj_fr_5_g": 0.2, "dj_fr_6": 80.8, "dj_fr_6_g": 0.5, "dj_fr_7": 112.0, "dj_fr_7_g": 1.5, "dm_fr_1": 89.4, "dm_fr_1_g": 0.2, "dm_fr_2": 89.0, "dm_fr_2_g": 1.4, "dm_fr_3": 61.5, "dm_fr_3_g": 1.2, "dm_fr_4": 61.1, "dm_fr_4_g": 0.4, "dm_fr_5": 37.8, "dm_fr_5_g": 1.2, "dm_fr_6": 47.4, "dm_fr_6_g": 0.2, "dm_fr_7": 84.0, "dm_fr_7_g": 0.2, "dm_fr_8": 59.2, "dm_fr_8_g": 0.4, "dm_fr_9": 130.3, "dm_fr_9_g": 0.5, "dm_fr_10": 104.4, "dm_fr_10_g": 0.6, "dm_fr_11": 120.0, "dm_fr_11_g": 1.2, "dm_fr_12": 119.2, "dm_fr_12_g": 1.5, "espace": 5.3, "dn_1": 11.3, "dn_1_g": 1.2, "dn_2": 12.1, "dn_2_g": 0.4, "dn_3": 12.1, "dn_3_g": 0.4, "dn_4": 12.2, "dn_4_g": 0.2, "dn_5": 12.2, "dn_5_g": 0.4, "dn_6": 12.2, "dn_6_g": 0.5, "dn_7": 12.2, "dn_7_g": 0.4, "dn_8": 12.5, "dn_8_g": 0.2, "dn_9": 12.1, "dn_9_g": 0.4, "dn_10": 22.5, "dn_10_g": 1.2, "dn_11": 22.6, "dn_11_g": 1.2, "dn_12": 22.5, "dn_12_g": 1.2, "dn_13": 22.5, "dn_13_g": 1.2, "dn_14": 22.5, "dn_14_g": 1.2, "dn_15": 22.5, "dn_15_g": 1.2, "dn_16": 22.6, "dn_16_g": 1.2, "dn_17": 22.5, "dn_17_g": 1.2, "dn_18": 22.6, "dn_18_g": 1.2, "dn_19": 22.5, "dn_19_g": 1.2, "dn_20": 23.4, "dn_20_g": 0.4, "dn_21": 23.4, "dn_21_g": 0.4, "dn_22": 23.4, "dn_22_g": 0.4, "dn_23": 23.4, "dn_23_g": 0.4, "dn_24": 23.4, "dn_24_g": 0.4, "dn_25": 23.4, "dn_25_g": 0.4, "dn_26": 23.5, "dn_26_g": 0.4, "dn_27": 23.4, "dn_27_g": 0.4, "dn_28": 23.5, "dn_28_g": 0.4, "dn_29": 23.4, "dn_29_g": 0.4, "dn_30": 23.4, "dn_30_g": 0.4, "dn_31": 23.4, "dn_31_g": 0.4, "dn_1er": 40.2, "dn_1er_g": 1.2, "date_base": 326.8, "petit_base": 25, "v": 18, "v_esp": -4, "v_encre0": 1.4, "v_moins": 12, "v_null": 20, "v_deg": 14, "meteo_ecart": 4.9, "temp_x": 101, "meteo_y": 337, "langue": "en"}
const PAD = 2
const HEURES = ["twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven"]
const UNITES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
const DIX = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
  "nineteen"]
const DIZAINES = ["", "", "twenty", "thirty", "forty", "fifty"]
const HEURES_FR = ["minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze",
  "midi", "treize", "quatorze", "quinze", "seize", "dixsept", "dixhuit", "dixneuf", "vingt", "vingtetune",
  "vingtdeux", "vingttrois"]
const UNITES_FR = ["", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf"]
const DIX_FR = ["dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"]
const DIZAINES_FR = ["", "", "vingt", "trente", "quarante", "cinquante"]

let lots = []
let texteTemps = null
let texteMeteo = null

// un lot d'images par ecran (normal, AOD), tous mis a jour par le meme capteur
function creerTexte(niveau) {
  const img = function () {
    return hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: "mt_one.png", show_level: niveau })
  }
  const lot = { mots: [], pm: null, date: [] }
  for (let i = 0; i < 3; i++) lot.mots.push(img())
  lot.pm = img()
  for (let i = 0; i < 3; i++) lot.date.push(img())
  lots.push(lot)
  if (texteTemps) return
  texteTemps = hmSensor.createSensor(hmSensor.id.TIME)
  texteMeteo = hmSensor.createSensor(hmSensor.id.WEATHER)
  texteTemps.addEventListener(texteTemps.event.MINUTEEND, majTexte)
}

// anglais, 12 h : heure, puis l'heure pile / oh + unite / dix a dix-neuf / dizaine + unite
function lignesHeure(h, m) {
  const l = [HEURES[h % 12]]
  if (m == 0) l.push("oclock")
  else if (m < 10) l.push("oh", UNITES[m])
  else if (m < 20) l.push(DIX[m - 10])
  else if (m % 10 == 0) l.push(DIZAINES[m / 10])
  else l.push(DIZAINES[Math.floor(m / 10)], UNITES[m % 10])
  return l
}

// francais, 24 h : quatorze / cinq, quatorze / quarante / six ; le mot heures est un marqueur a part
function lignesHeureFr(h, m) {
  const l = [HEURES_FR[h]]
  if (m == 0) return l
  if (m < 10) l.push(UNITES_FR[m])
  else if (m < 17) l.push(DIX_FR[m - 10])
  else if (m < 20) l.push("dix", UNITES_FR[m - 10])
  else if (m % 10 == 0) l.push(DIZAINES_FR[m / 10])
  else l.push(DIZAINES_FR[Math.floor(m / 10)], m % 10 == 1 ? "etune" : UNITES_FR[m % 10])
  return l
}

function poser(w, src, x, y) {
  w.setProperty(hmUI.prop.MORE, { x: Math.round(x), y: Math.round(y), src: src })
  w.setProperty(hmUI.prop.VISIBLE, true)
}

function majTexte() {
  for (let i = 0; i < lots.length; i++) poserTexte(lots[i])
  majMeteo()
}

function poserTexte(lot) {
  const fr = TABLE.langue == "fr"
  // bloc pose sur le filet : moins de trois lignes occupent les places du bas
  const l = fr ? lignesHeureFr(texteTemps.hour, texteTemps.minute) : lignesHeure(texteTemps.hour, texteTemps.minute)
  const d = 3 - l.length
  for (let i = 0; i < 3; i++) {
    if (i < l.length) poser(lot.mots[i], "mt_" + l[i] + ".png", TABLE.marge - PAD, TABLE.bases[d + i] - TABLE.mot_base)
    else lot.mots[i].setProperty(hmUI.prop.VISIBLE, false)
  }
  if (fr) {
    // heures en vertical colle au mot de l'heure, pied sur sa ligne de base ; rien pour midi et minuit
    const h = texteTemps.hour
    if (h == 0 || h == 12) lot.pm.setProperty(hmUI.prop.VISIBLE, false)
    else {
      const v = h == 1 ? "mt_vheure" : "mt_vheures"
      const x = TABLE.marge + TABLE["mt_" + l[0]] + TABLE.marqueur_ecart - PAD
      poser(lot.pm, v + ".png", x, TABLE.bases[d] - TABLE[v + "_h"] - PAD)
    }
  } else {
    const pm = texteTemps.hour < 12 ? "mt_am" : "mt_pm"
    const fin = TABLE.marge + TABLE["mt_" + l[l.length - 1]]
    poser(lot.pm, pm + ".png", fin + TABLE.pm_ecart - PAD, TABLE.bases[2] - TABLE.mot_base)
  }

  // date : jour, quantieme sans zero (1er en francais), mois, espaces avec les approches de la police
  const y = TABLE.date_base - TABLE.petit_base
  const jour = fr && texteTemps.day == 1 ? "dn_1er" : "dn_" + texteTemps.day
  const morceaux = ["dj_" + TABLE.langue + "_" + texteTemps.week, jour, "dm_" + TABLE.langue + "_" + texteTemps.month]
  let x = TABLE.marge
  for (let i = 0; i < 3; i++) {
    if (i) x += TABLE.espace + TABLE[morceaux[i] + "_g"]
    poser(lot.date[i], morceaux[i] + ".png", x - PAD, y)
    x += TABLE[morceaux[i]]
  }
}

// le mot meteo de l'editeur suit la largeur reelle de la temperature (1 a 3 caracteres, ou --)
function majMeteo() {
  try {
    const t = texteMeteo.current
    const s = t == undefined ? "" : String(t)
    const n = s.replace("-", "").length
    const pas = s.length * TABLE.v_esp + n * TABLE.v + (s.length - n) * TABLE.v_moins
    const fin = TABLE.temp_x + (s ? pas + TABLE.v_deg : TABLE.v_null)
    const images = []
    for (let i = 1; i <= 29; i++) images.push("meteo_" + TABLE.langue + "_" + i + ".png")
    normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
      x: Math.round(fin + TABLE.meteo_ecart - PAD), y: TABLE.meteo_y, image_array: images, image_length: 29,
      type: hmUI.data_type.WEATHER_CURRENT, show_level: hmUI.show_level.ONLY_NORMAL,
    })
  } catch (e) {}
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond_en.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 146,
              y: 337,
              image_array: ["meteo_en_1.png","meteo_en_2.png","meteo_en_3.png","meteo_en_4.png","meteo_en_5.png","meteo_en_6.png","meteo_en_7.png","meteo_en_8.png","meteo_en_9.png","meteo_en_10.png","meteo_en_11.png","meteo_en_12.png","meteo_en_13.png","meteo_en_14.png","meteo_en_15.png","meteo_en_16.png","meteo_en_17.png","meteo_en_18.png","meteo_en_19.png","meteo_en_20.png","meteo_en_21.png","meteo_en_22.png","meteo_en_23.png","meteo_en_24.png","meteo_en_25.png","meteo_en_26.png","meteo_en_27.png","meteo_en_28.png","meteo_en_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 337,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'v_deg.png',
              unit_tc: 'v_deg.png',
              unit_en: 'v_deg.png',
              negative_image: 'v_minus.png',
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 372,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'v_pas_en.png',
              unit_tc: 'v_pas_en.png',
              unit_en: 'v_pas_en.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 337,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'v_pct.png',
              unit_tc: 'v_pct.png',
              unit_en: 'v_pct.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
creerTexte(hmUI.show_level.ONLY_NORMAL)
creerTexte(hmUI.show_level.ONLY_AOD)
majTexte()

            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 297,
              src: 'filet_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 371,
              w: 200,
              h: 32,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 336,
              w: 90,
              h: 32,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 336,
              w: 200,
              h: 32,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 107,
              w: 320,
              h: 184,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 301,
              w: 300,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

majTexte()

                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}