﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_calorie_image_progress_img_progress = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let idle_step_icon_img = ''
        let idle_step_image_progress_img_progress = ''
        let idle_bio_charge_icon_img = ''
        let idle_bio_charge_image_progress_img_progress = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

            // jauges bornees a 100 % : une image par niveau, mise a jour a chaque minute et au reveil
            const jauges = []
            const capteurs = {}
            function capteur(id) {
              if (!capteurs[id]) capteurs[id] = hmSensor.createSensor(hmSensor.id[id])
              return capteurs[id]
            }
            function progression(id) {
              // un capteur absent ne doit pas interrompre la creation du cadran : jauge vide
              try {
                const c = capteur(id)
                if (id === 'PAI') return (c.totalpai || 0) / 100
                if (id === 'BATTERY') return (c.current || 0) / 100
                return c.target ? (c.current || 0) / c.target : 0
              } catch (e) {
                return 0
              }
            }
            function majJauge(j) {
              const k = Math.round(Math.max(0, Math.min(1, progression(j.id))) * j.n)
              j.w.setProperty(hmUI.prop.MORE, { x: j.x, y: j.y, src: j.prefixe + (k < 10 ? '0' : '') + k + '.png' })
            }
            function jauge(id, x, y, prefixe, n, niveau) {
              const j = { id, x, y, prefixe, n }
              j.w = hmUI.createWidget(hmUI.widget.IMG, { x, y, src: prefixe + '00.png', show_level: niveau })
              jauges.push(j)
              majJauge(j)
            }
            function majJauges() {
              jauges.forEach(majJauge)
            }
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            jauge('BATTERY', 4, 4, 'batc_', 22, hmUI.show_level.ONLY_NORMAL);

            jauge('CALORIE', 245, 245, 'kcalc_', 22, hmUI.show_level.ONLY_NORMAL);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 284,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 378,
              font_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'w_deg.png',
              unit_tc: 'w_deg.png',
              unit_en: 'w_deg.png',
              negative_image: 'w_moins.png',
              invalid_image: 'w_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177, w: 70,
              y: 378,
              font_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'w_sep.png',
              unit_tc: 'w_sep.png',
              unit_en: 'w_sep.png',
              negative_image: 'w_moins.png',
              invalid_image: 'w_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202, w: 75,
              y: 336,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't_deg.png',
              unit_tc: 't_deg.png',
              unit_en: 't_deg.png',
              negative_image: 't_moins.png',
              invalid_image: 't_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 117,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 253,
              day_startY: 119,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_fond.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 216,
              src: 'ic_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            jauge('STEP', 42, 162, 'ring_', 30, hmUI.show_level.ONLY_AOD);

            idle_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 218,
              src: 'ic_bio_charge.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [362,375,388,400,410,418,424,427,424,418,410,399,388,374,361,345,330,317,305,296,290,287,286,287,290,296,306,317,331,346],
              y: [162,164,168,176,187,200,214,229,244,257,270,281,290,297,301,301,297,290,280,269,257,243,228,213,199,186,176,168,163,162],
              image_array: ["anneau_01.png","anneau_02.png","anneau_03.png","anneau_04.png","anneau_05.png","anneau_06.png","anneau_07.png","anneau_08.png","anneau_09.png","anneau_10.png","anneau_11.png","anneau_12.png","anneau_13.png","anneau_14.png","anneau_15.png","anneau_16.png","anneau_17.png","anneau_18.png","anneau_19.png","anneau_20.png","anneau_21.png","anneau_22.png","anneau_23.png","anneau_24.png","anneau_25.png","anneau_26.png","anneau_27.png","anneau_28.png","anneau_29.png","anneau_30.png"],
              image_length: 30,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 117,
              week_en: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              week_tc: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              week_sc: ["aod_day_en_01.png","aod_day_en_02.png","aod_day_en_03.png","aod_day_en_04.png","aod_day_en_05.png","aod_day_en_06.png","aod_day_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 253,
              day_startY: 119,
              day_sc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_tc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_en_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_aig_h.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_aig_m.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 38,
              y: 158,
              w: 160,
              h: 160,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: 100001, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: 100003, preview: 'prev_uvi.png', title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: 100004, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: 100005, preview: 'prev_altitude.png', title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100006, preview: 'prev_humidity.png', title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
              ],
              count: 11,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 5,
              tips_y: 162,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 70, w: 95,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 102,
                  y: 196,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                jauge('STEP', 42, 162, 'ring_', 30, hmUI.show_level.ONLY_NORMAL);
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 90, w: 57,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 41,
                  y: 161,
                  src: 'zic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 90, w: 57,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 95,
                  y: 206,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                jauge('PAI', 42, 162, 'ring_', 30, hmUI.show_level.ONLY_NORMAL);
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 76, w: 83,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 41,
                  y: 161,
                  src: 'zic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 82, w: 73,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 41,
                  y: 161,
                  src: 'zic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 90, w: 57, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 97, y: 198, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG_PROGRESS, { x: [118, 131, 144, 156, 166, 174, 180, 183, 180, 174, 166, 155, 144, 130, 117, 101, 86, 73, 61, 52, 46, 43, 42, 43, 46, 52, 62, 73, 87, 102], y: [162, 164, 168, 176, 187, 200, 214, 229, 244, 257, 270, 281, 290, 297, 301, 301, 297, 290, 280, 269, 257, 243, 228, 213, 199, 186, 176, 168, 163, 162], image_array: ["anneau_01.png","anneau_02.png","anneau_03.png","anneau_04.png","anneau_05.png","anneau_06.png","anneau_07.png","anneau_08.png","anneau_09.png","anneau_10.png","anneau_11.png","anneau_12.png","anneau_13.png","anneau_14.png","anneau_15.png","anneau_16.png","anneau_17.png","anneau_18.png","anneau_19.png","anneau_20.png","anneau_21.png","anneau_22.png","anneau_23.png","anneau_24.png","anneau_25.png","anneau_26.png","anneau_27.png","anneau_28.png","anneau_29.png","anneau_30.png"], image_length: 30, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 99, w: 38, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 41, y: 161, src: 'zic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 99, w: 38, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 41, y: 161, src: 'zic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 80, w: 76, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 41, y: 161, src: 'zic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 80, w: 76, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 41, y: 161, src: 'zic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 82, w: 73, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 41, y: 161, src: 'zic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 282,
              y: 158,
              w: 160,
              h: 160,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100001,
              optional_types: [
                { type: 100001, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: 100003, preview: 'prev_uvi.png', title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: 100004, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: 100005, preview: 'prev_altitude.png', title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100006, preview: 'prev_humidity.png', title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
              ],
              count: 11,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 5,
              tips_y: 162,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 314, w: 95,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 346,
                  y: 196,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                jauge('STEP', 286, 162, 'ring_', 30, hmUI.show_level.ONLY_NORMAL);
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 334, w: 57,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 285,
                  y: 161,
                  src: 'zic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 334, w: 57,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 339,
                  y: 206,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                jauge('PAI', 286, 162, 'ring_', 30, hmUI.show_level.ONLY_NORMAL);
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 320, w: 83,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 285,
                  y: 161,
                  src: 'zic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 326, w: 73,
                  y: 250,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 285,
                  y: 161,
                  src: 'zic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 334, w: 57, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 341, y: 198, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG_PROGRESS, { x: [362, 375, 388, 400, 410, 418, 424, 427, 424, 418, 410, 399, 388, 374, 361, 345, 330, 317, 305, 296, 290, 287, 286, 287, 290, 296, 306, 317, 331, 346], y: [162, 164, 168, 176, 187, 200, 214, 229, 244, 257, 270, 281, 290, 297, 301, 301, 297, 290, 280, 269, 257, 243, 228, 213, 199, 186, 176, 168, 163, 162], image_array: ["anneau_01.png","anneau_02.png","anneau_03.png","anneau_04.png","anneau_05.png","anneau_06.png","anneau_07.png","anneau_08.png","anneau_09.png","anneau_10.png","anneau_11.png","anneau_12.png","anneau_13.png","anneau_14.png","anneau_15.png","anneau_16.png","anneau_17.png","anneau_18.png","anneau_19.png","anneau_20.png","anneau_21.png","anneau_22.png","anneau_23.png","anneau_24.png","anneau_25.png","anneau_26.png","anneau_27.png","anneau_28.png","anneau_29.png","anneau_30.png"], image_length: 30, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 343, w: 38, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 161, src: 'zic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 343, w: 38, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 161, src: 'zic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 324, w: 76, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 161, src: 'zic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 324, w: 76, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 161, src: 'zic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 326, w: 73, y: 250, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: 0, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 285, y: 161, src: 'zic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aig_h.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aig_m.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'aig_s.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            try {
              const jaugesTemps = hmSensor.createSensor(hmSensor.id.TIME)
              jaugesTemps.addEventListener(jaugesTemps.event.MINUTEEND, majJauges)
            } catch (e) {}
            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: majJauges })
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 340,
              w: 72,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 77,
              w: 75,
              h: 71,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 191,
              w: 105,
              h: 94,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 174,
              y: 108,
              w: 131,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 290,
              w: 128,
              h: 128,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}